README for memegenerator.net dataset

Dataset originally created 05/07/2018
UPDATED 10/04/2018 (removed file name column)

This dataset includes one CSV file:

- memegenerator.csv

The Meme Generator data set includes 86,310 total memes harvested from [Meme Generator](https://www.loc.gov/item/lcwaN0010226/). There are 57,652 unique meme instances derived from base memes (meme images without text, waiting to be fashioned into meme instances). The data set include some minimal metadata for these Memes. The data set does not include the Memes themselves, however it does provide links to where you can access their web archive copies within the Library's web archive.

Created by Chase Dooley, Digital Collections Specialist, DCM, Library of Congress.
